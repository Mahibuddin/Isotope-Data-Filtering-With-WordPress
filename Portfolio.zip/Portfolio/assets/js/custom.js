/*==================================
* Author        : "HelloXpert"
* Template Name :  "HELLO"  |  HTML Template
* Version       : 1.0
==================================== */


        /*=========== TABLE OF CONTENTS ===========
		## preloader
		## progress-bar
		## wow js
		## scrollUp
		## particlesJS
		## Create the map
		## for counter up
		## for corp-brand branding
		## for Home page Slider Revolution
======================================*/

	
	  
	  
jQuery(document).ready(function () {
	"use strict";
	
	
	
		//Isotop
		    jQuery(".project-title li").on('click',function(){

		        jQuery('.project-title li').removeClass('active');
		        jQuery(this).addClass('active');

		        var selector = jQuery(this).attr('data-filter');
		        jQuery(".project-list").isotope({
		            filter : selector
		        })
		    });
			
	
	

});

