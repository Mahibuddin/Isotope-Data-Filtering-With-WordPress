<?php
/*-----------------------------------------------------------------------------------*/
/*	Register & enqueue styles/scripts Start
/*-----------------------------------------------------------------------------------*/ 

//Enqueue Css Files
function hello_css_js() {
	
//Enqueue Js Files	 
	wp_enqueue_script( 'isotop', get_template_directory_uri() . '/assets/js/isotope.pkgd.min.js', array('jquery'), '3.0.6', true );
	wp_enqueue_script( 'hello_custom', get_template_directory_uri() . '/assets/js/custom.js', array('jquery'), '1.0.0', true );	
}
add_action( 'wp_enqueue_scripts', 'hello_css_js' );

