<?php


//  Shortcode for Custom Post

add_shortcode('portfolio_q', 'carrer_shortcode_query');
function carrer_shortcode_query($atts, $content){ ?>

	 <div class="section-padding">
	    <div class="container">
	        <div class="row">
	            <div class="col-md-12">
	                <ul class="project-title">
	                    <li class="active" data-filter="*">All</li>
						
						<?php 
					
							$terms = get_terms('cptcategory');
							foreach($terms as $term){
								
								echo "<li data-filter=\".$term->slug\">$term->name</li>";
							}
						?>
	                </ul>
	                <div class="row project-list">   
						<?php
							global $post;
					        wp_reset_query();
					        $atts = array( 
					        'posts_per_page' => 6, 
					        'post_type' => 'portfolio',
					        'orderby' => 'date', 
					        'order' => 'DESC', 
					        'update_post_term_cache' => false, 
					        'update_post_meta_cache' => false 
					    ); 
						$posts = new WP_Query($atts);

							if ($posts->have_posts())
						        while ($posts->have_posts()):
						            $posts->the_post(); 
												
						?>
						<?php 
							$terms = get_the_terms( get_the_ID(), 'cptcategory' );
	                     
								if ( $terms && ! is_wp_error( $terms ) ) : 
								 
									$draught_links = array();
								 
									foreach ( $terms as $term ) {
										$draught_links[] = $term->slug;
									}
														 
							$on_draught = join( " ", $draught_links );
						?>

	                    <div class="col-md-4 <?php echo $on_draught;?>">
							
		                    	<?php
				            		global $post;
				            		$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
									$thumb[0];
				            	?>
		                        <div class="project-img" style="background: url('<?php echo $thumb['0'] ; ?>')">
		                        </div>
                                <div class="project-img-info">
                                	<div class="project-entry-info">
		                        		<a href="<?php echo get_post_meta( $post->ID, 'link', true ); ?>">
											<h2 class="test-title"><?php the_title(); ?></h2>
										</a>
		                     
						      			<?php echo get_the_term_list(get_the_ID(), 'cptcategory', '', ', ', ''); ?> 
                                	</div>
	                    		</div>
	                    	</div>

	                    <?php endif; endwhile;?>
                    </div>
	            </div>
	        </div>
	    </div>
	</div>
<?php
	    wp_reset_postdata(); 
}