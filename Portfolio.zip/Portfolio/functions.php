<?php
if(file_exists(get_template_directory().'/inc/enqueue.php')){
require_once(get_template_directory().'/inc/enqueue.php');
}
if(file_exists(get_template_directory().'/inc/custom_post_type.php')) {
	require_once(get_template_directory().'/inc/custom_post_type.php');
}
if(file_exists(get_template_directory().'/inc/custom_shortcode.php')) {
	require_once(get_template_directory().'/inc/custom_shortcode.php');
}



