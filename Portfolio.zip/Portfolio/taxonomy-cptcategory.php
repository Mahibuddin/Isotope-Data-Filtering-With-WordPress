<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 *
 * @package WordPress
 * @subpackage Webspreed
 * @since Webspreed 1.0
 */
get_header(); ?>
<!-- Corporate Banner Start -->
<?php
    // banner
if(cs_get_option('archive_banner_thumb')) { ?>
<div id="corporate-banner" class="corporate-blog-grid-banner" style="background: url(<?php 
            echo esc_url(cs_get_option('archive_banner_thumb'));
        ?>)no-repeat center / cover"> <?php } else{?>
<div id="corporate-banner" class="corporate-blog-grid-banner" >
        <?php } ?>
    <?php
    // banner overlay
    if(cs_get_option('archive_banner_overly')) { ?>
    <div class="corporate-banner-overlay" style="background: <?php 
            echo esc_url(cs_get_option('archive_banner_overly'));
        ?>"></div> <?php } else{?>
    <div class="corporate-banner-overlay"></div>
        <?php } ?>
    <div  id="particles-js"></div>
        <div class="container">
            <div class="banner-txt">
                <div class="banner-title pull-left">
                    <header class="page_header">
                        <?php
                            the_archive_title( '<h1 class="page-title">', '</h1>' );
                            the_archive_description( '<div class="taxonomy-description">', '</div>' );
                        ?>
                    </header>         
                </div>  
                <div class="banner-bb pull-right">
                    <?php if (function_exists('hello_breadcrumb')) hello_breadcrumb(); ?>
                </div>
            </div>
        </div>
</div><!-- /#corporate-banner -->

    
<!-- Corporate Blog Start -->
<div id="corporate-blog-page">
    <div class="corporate-blog corp-sec-pd corp-sec-bg1">
        <div class="container">
            <div class="corp-blog-all">
                <div class="row">
                    <?php
                        $case_study_cat_slug = get_queried_object()->slug;
                        $case_study_cat_name = get_queried_object()->name;
                    ?>
                    <?php
                        $current_page = (get_query_var('page')) ? get_query_var('page') : 1;
                        $hello_blog_post = new WP_Query(array(
                            'post_type'=>'portfolio',
                            'posts_per_page' => 2,
                            'orderby' => 'date', 
                            'order' => 'DESC',

                            'update_post_term_cache' => false, 
                            'update_post_meta_cache' => false, 
                            'paged'=>$current_page,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'cptcategory',
                                    'field' => 'slug',
                                    'terms' => $case_study_cat_slug
                                )
                            )
                        ));
                        //post condition
                        if($hello_blog_post-> have_posts()) : while($hello_blog_post-> have_posts()) : $hello_blog_post-> the_post();
                        /*
                         * Include the Post-Format-specific template for the content.
                         * If you want to override this in a child theme, then include a file
                         * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                         */
                        // get_template_part( 'template-parts/content.php', get_post_format() );
                    ?>

                    <div class="col-md-4">
                        <?php
                            $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
                            $thumb[0];
                        ?>
                         
                        <div class="project-img" style="background: url('<?php echo $thumb['0'] ; ?>')">
                        </div>
                        <div class="project-img-info">
                            <div class="project-entry-info">
                                
                                <a href="<?php echo get_post_meta( $post->ID, 'link', true ); ?>" class="text-title">
                                    <h2 class="taxo-title"><?php the_title(); ?></h2>
                                </a>
                     
                                <?php echo get_the_term_list(get_the_ID(), 'cptcategory', '', ', ', ''); ?> 
                            </div>
                        </div>
                    </div>

                    <?php endwhile; ?>
                    <?php
                        //$args If no content, include the "No posts found" template.
                        else :
                        get_template_part( 'template-parts/content', 'none' );
                        endif;          
                    ?>
                </div><!-- /.row -->
                <div class="corp-pz text-center">
                  <ul class="pagination">  
                      <?php
                            // Previous/next page navigation.
                            echo paginate_links( array(
                                //'mid_size'      => 5,
                                'prev_text'     => esc_html__( 'prev', 'Webspreed' ),
                                'next_text'     => esc_html__( 'Next', 'Webspreed' ),
                                'total'         => $hello_blog_post->max_num_pages
                            ) );
                        ?>
                  </ul>
                </div>
            </div>
        </div><!-- /.container -->
    </div>
</div><!-- /#corporate-Blog --> 
  

<?php get_footer();?>